#!/bin/bash

vasprun_file=$1

python3 -c "import numpy as np; from ase.io import read; \
 steps=read('$vasprun_file',index=':'); \
 print('\n'.join([f'{i+1} {step.get_potential_energy()}\
 {max(np.linalg.norm(step.get_forces(),axis=1))}'\
 for i,step in enumerate(steps)]))"\
 > force.dat 

#gnuplot -persist -e "plot 'force.dat' u 1:2 w lp"
#gnuplot -persist -e "set log y; plot 'force.dat' u 1:3 w lp"
gnuplot -persist -e "set y2tics; set log y2; \
plot 'force.dat' u 1:2 w lp, 'force.dat' u 1:3 ax x1y2 w lp"

