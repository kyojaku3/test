#!/usr/bin/env python3
# ini:20221025, update:20240605
# $ time python3 rings.py movie.xyz tmp_v134 -v 134 --command ~/code/rings-code-v1.3.4/src/rings --is_calc

import argparse
import glob
import os
import shutil
import subprocess
import sys
import yaml
from ase.io import read

class RINGS_USERSET:

    def __init__(self, atomsfile, version=128):
        atoms = read(atomsfile, index=':')
        nstep = len(atoms)
        natom = atoms[-1].get_global_number_of_atoms()
        cell = atoms[-1].get_cell()
        symbols = atoms[-1].get_chemical_symbols()
        typat = {}
        for s in symbols:
            typat[s] = 0
        for s in symbols:
            typat[s] = typat[s] + 1
        print("symbols = ", symbols)
        print("typat = ", typat)
        self.atomsfile = atomsfile
        self.atoms = atoms
        self.natom = natom
        self.nstep = nstep
        self.typat = typat
        self.ntypat = len(typat)
        self.symbols = symbols
        self.cell = cell
        self.version = version


    def calculate(self, command=None):

        if command is None:
#            command = os.environ.get('RINGS_COMMAND')
            command = 'rings'
        command = '{rings} {inputfile}'.format(rings=command, inputfile=self.inputfile)
        print("command = " + command)

        print('Running RINGS code')
        try:
            proc = subprocess.Popen(command, shell=True, cwd=self.outdir)
        except OSError as err:
            msg = 'Failed to execute "{}"'.format(command)
            raise EnvironmentError(msg) from err

        errorcode = proc.wait()

        if errorcode:
            path = os.path.abspath(self.outdir)
            msg = ('Command "{}" failed in '
                   '{} with error code {}'.format(command,
                                                  path, errorcode))
            raise CalculationFailed(msg)
        print('Done: RINGS code')


    def make_input(self,
        outdir,
        cut_off_dict,
        inputfile = 'in.rings',
        optionfile = 'options',
        user_input_settings = None,
        user_option_settings = None,
    ):

        self.outdir = outdir
        self.inputfile = inputfile
        self.optionfile = optionfile

        if not os.path.exists(self.outdir):
            os.makedirs(self.outdir)

        datadir = os.path.join(self.outdir, 'data')
        if not os.path.exists(datadir):
            os.makedirs(datadir)

        shutil.copy(self.atomsfile, datadir)
        cwd = os.getcwd()
        os.chdir(self.outdir)

        input_settings = {}
        option_settings = {}

        input_settings.update({
  'system_name' : "test",
  'natom' : self.natom,
  'ntypat' : self.ntypat,
  'symbols' : self.symbols,
  'nstep' : self.nstep,
  'optlat' : 1,
  'cell' : self.cell,
  'dtion' : 1.0,
  'optform' : 'ANI',
  'atomfile' : self.atomsfile,
  'n_dr_gr' : 200,
  'n_dq' : 500,
  'Sq_mod' : 25,
  'fact_smooth' : 0.125,
#  'fact_smooth' : 1.0,
  'n_adf' : 90,
  'n_dr_ring' : 20,
  'max_ring' : 10,
  'max_chain' : 15,
  'cut_off_dict' : cut_off_dict,
        }) 

        option_settings.update({
  'PBC' : ".true.",
  'Frac' : ".false.",
  'g(r)' : ".false.",
  'S(q)' : ".false.",
  'S(k)' : ".false.",
  'gfft(r)' : ".false.",
  'MSD' : ".false.",
  'atMSD' : ".false.",
  'Bonds' : ".false.",
  'Angles' : ".false.",
  'Chains' : ".false.",
  'Ch_dict' : {
              'Species' : 0,
              'AAAA' : ".false.",
              'ABSB' : ".false.",
              '1221' : ".false.",
  },
  'Rings' : ".false.",
  'R_dict' : {
              'Species' : 0,
              'ABAB' : ".false.",
              'Rings0' : ".false.",
              'Rings1' : ".false.",
              'Rings2' : ".false.",
              'Rings3' : ".true.",
              'Rings4' : ".true.",
              'Prim_Rings' : ".true.",
              'Str_Rings' : ".false.",
              'BarycRings' : ".false.",
              'Prop-1' : ".false.",
              'Prop-2' : ".false.",
              'Prop-3' : ".false.",
              'Prop-4' : ".false.",
              'Prop-5' : ".false.",
  },
  'Vacuum' : ".false.",
  'Evol' : ".false.",
  'Dxout' : ".false.",
  'RadOut' : ".false.",
  'RingsOut' : ".false.",
  'DRngOut' : ".false.",
  'VoidsOut' : ".false.",
  'TetraOut' : ".false.",
  'TrajOut' : ".false.",
  'Output' : "out.rings",
        })


        if user_input_settings != None:
            input_settings.update(user_input_settings)

        if user_option_settings != None:
            option_settings.update(user_option_settings)


        with open(inputfile, 'w') as fo:
            print('''#######################################
#       R.I.N.G.S. input file         #
#######################################''', file=fo)
            
            print(input_settings['system_name'], file=fo)
            print(input_settings['natom'], file=fo)
            print(input_settings['ntypat'], file=fo)
            print(' '.join(list(dict.fromkeys(input_settings['symbols']))), file=fo)
            print(input_settings['nstep'], file=fo)
            print(input_settings['optlat'], file=fo)             
            for i in range(3):
                for j in range(3):
                    print("{:.6f} ".format(input_settings['cell'][i][j]), end="", file=fo)
                print("", file=fo)
            print(input_settings['dtion'], file=fo)
            print(input_settings['optform'], file=fo)
            print(input_settings['atomfile'], file=fo)
            print(input_settings['n_dr_gr'], file=fo)
            print(input_settings['n_dq'], file=fo)
            print(input_settings['Sq_mod'], file=fo)
            print(input_settings['fact_smooth'], file=fo)
            print(input_settings['n_adf'], file=fo)
            print(input_settings['n_dr_ring'], file=fo)
            print(input_settings['max_ring'], file=fo)
            if self.version > 128:
                print(input_settings['max_chain'], file=fo)
            print('''#######################################''', file=fo)
            for pair, rcut in input_settings['cut_off_dict'].items():
                if isinstance (pair, tuple ):
                    print("{pair}  {rcut}".format(pair=" ".join(pair), rcut=rcut), file=fo)
                else:
                    print("{pair}  {rcut}".format(pair=pair, rcut=rcut), file=fo)
            print('''#######################################''', file=fo)


        with open(optionfile, 'w') as fo:
            print('''#######################################
        R.I.N.G.S. options file       #
#######################################''', file=fo)
            print('PBC ', option_settings['PBC'], file=fo)
            print('Frac ', option_settings['Frac'], file=fo)
            print('g(r) ',option_settings['g(r)'], file=fo)
            print('S(q) ', option_settings['S(q)'], file=fo)
            print('S(k) ', option_settings['S(k)'], file=fo)
            print('gfft(r) ', option_settings['gfft(r)'], file=fo)
            print('MSD ', option_settings['MSD'], file=fo)
            print('atMSD ', option_settings['atMSD'], file=fo)
            print('Bonds ', option_settings['Bonds'], file=fo)
            print('Angles ', option_settings['Angles'], file=fo)
            if self.version > 128:
                print('Chains ', option_settings['Chains'], file=fo)
                print('----- ! Chain statistics options ! -----', file=fo)
                print('Species ', option_settings['Ch_dict']['Species'], file=fo)
                print('AAAA ', option_settings['Ch_dict']['AAAA'], file=fo)
                print('ABAB ', option_settings['Ch_dict']['AAAA'], file=fo)
                print('1221 ', option_settings['Ch_dict']['AAAA'], file=fo)
                print('---------------------------------------', file=fo)
            print('Rings ', option_settings['Rings'], file=fo)
            print('----- ! Ring statistics options ! -----', file=fo)
            print('Species ', option_settings['R_dict']['Species'], file=fo)
            print('ABAB ', option_settings['R_dict']['ABAB'], file=fo)
            print('Rings0 ', option_settings['R_dict']['Rings0'], file=fo)
            print('Rings1 ', option_settings['R_dict']['Rings1'], file=fo)
            print('Rings2 ', option_settings['R_dict']['Rings2'], file=fo)
            print('Rings3 ', option_settings['R_dict']['Rings3'], file=fo)
            print('Rings4 ', option_settings['R_dict']['Rings4'], file=fo)
            print('Prim_Rings ', option_settings['R_dict']['Prim_Rings'], file=fo)
            print('Str_Rings ', option_settings['R_dict']['Str_Rings'], file=fo)
            print('BarycRings ', option_settings['R_dict']['BarycRings'], file=fo)
            print('Prop-1 ', option_settings['R_dict']['Prop-1'], file=fo)
            print('Prop-2 ', option_settings['R_dict']['Prop-2'], file=fo)
            print('Prop-3 ', option_settings['R_dict']['Prop-3'], file=fo)
            print('Prop-4 ', option_settings['R_dict']['Prop-4'], file=fo)
            print('Prop-5 ', option_settings['R_dict']['Prop-5'], file=fo)
            print('---------------------------------------', file=fo)
            print('Vacuum ', option_settings['Vacuum'], file=fo)
            print('''#######################################
         Outputting options           #
#######################################''', file=fo)
            print('Evol ', option_settings['Evol'], file=fo)
            print('Dxout ', option_settings['Dxout'], file=fo)
            print('-- ! OpenDX visualization options !  --', file=fo)
            print('RadOut ', option_settings['RadOut'], file=fo)
            print('RingsOut ', option_settings['RingsOut'], file=fo)
            print('DRngOut ', option_settings['DRngOut'], file=fo)
            print('VoidsOut ', option_settings['VoidsOut'], file=fo)
            print('TetraOut ', option_settings['TetraOut'], file=fo)
            print('TrajOut ', option_settings['TrajOut'], file=fo)
            print('--------------------------------------- ', file=fo)
            print('Output ', option_settings['Output'], file=fo)
            print('#######################################', file=fo)

        os.chdir(cwd)

if __name__ == "__main__":

    parser = argparse.ArgumentParser()
    parser.add_argument('atomsfile', type=str, help="calculation directory by rings code")
    parser.add_argument('outdir', type=str, help="calculation directory by rings code")
    parser.add_argument('-fc', '--cutoff_file', type=str, default='cutoff.yaml')
    parser.add_argument('-v', '--version', type=int, default=128, help="Version of RINGS code")
    parser.add_argument('--command', type=str, default=None, help="RINGS command")
    parser.add_argument('--is_calc', action='store_true')
    args = parser.parse_args()

    print("outdir = {}".format(args.outdir))

    rings = RINGS_USERSET(args.atomsfile, version=args.version)

    cut_off_dict = {}
    with open(args.cutoff_file, 'r') as file:
        cutoff_data = yaml.safe_load(file)
    for key,val in cutoff_data.items():
        cut_off_dict[('{}'.format(val[0]),'{}'.format(val[1]))] = val[2]
    cut_off_dict['Grtot']=max(cut_off_dict.values())
    print('cutoff=',cut_off_dict)

    user_input_settings = {}
    user_option_settings = {}

    user_option_settings.update({'g(r)': '.true', 'Angles': '.true.'})

    rings.make_input(args.outdir, cut_off_dict, 
                     user_input_settings = user_input_settings,
                     user_option_settings = user_option_settings)

    if args.is_calc:
        rings.calculate(command = args.command)

