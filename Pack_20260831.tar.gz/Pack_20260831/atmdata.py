#!/usr/bin/env python3
# ini:20151123, update:20201027
# usage: $ atmdata.py 6
# TODO: complete symbol->znucl conversion

"""Module to return atomic data
usage:
from Python3.atmdata import atmdata
for itypat in range(ntypat):
    [amu[itypat],rcov[itypat],symbol[itypat]] = atmdata(znucltypat[itypat])
    print(str(amu[itypat])+' '+str(rcov[itypat])+' '+str(symbol[itypat]))
"""

def symbol2znucl(symbol):
    """convert symbol to znucl"""
#    print(symbol)
    if len(symbol) == 1: symbol = " " + symbol
#    print(symbol)

    if symbol == 'no':
        znucl=0
    elif symbol == ' H' or symbol== 'H ':
        znucl=1
    elif symbol == 'He':
        znucl=2
    elif symbol == 'Li':
        znucl=3
    elif symbol == 'Be':
        znucl=4;
    elif symbol == ' B' or symbol == 'B ':
        znucl=5
    elif symbol == ' C' or symbol == 'C ':
        znucl=6
    elif symbol == ' N' or symbol == 'N ':
        znucl=7
    elif symbol == ' O' or symbol == 'O ':
        znucl=8
    elif symbol == ' F' or symbol == 'F ':
        znucl=9   
    elif symbol == 'Ne':
        znucl=10
    elif symbol == 'Na':
        znucl=11
    elif symbol == 'Mg':
        znucl=12
    elif symbol == 'Al':
        znucl=13
    elif symbol == 'Si':
        znucl=14
    elif symbol == ' P' or symbol == 'P ':
        znucl=15
    elif symbol == ' S' or symbol == 'S ':
        znucl=16
    elif symbol == 'Cl':
        znucl=17
    elif symbol == 'Ar':
        znucl=18
    elif symbol == ' K' or symbol == 'K ':
        znucl=19    
    elif symbol == 'Ca':
        znucl=20
    elif symbol == 'Sc':
        znucl=21
    elif symbol == 'Ti':
        znucl=22
    elif symbol == ' V' or symbol == 'V ':
        znucl=23
    elif symbol == 'Cr':
        znucl=24
    elif symbol == 'Mn':
        znucl=25
    elif symbol == 'Fe':
        znucl=26
    elif symbol == 'Co':
        znucl=27
    elif symbol == 'Ni':
        znucl=28
    elif symbol == 'Cu':
        znucl=29     
    elif symbol == 'Zn':
        znucl=30
    elif symbol == 'Ga':
        znucl=31
    elif symbol == 'Ge':
        znucl=32
    elif symbol == 'As':
        znucl=33
    elif symbol == 'Se':
        znucl=34
    elif symbol == 'Br':
        znucl=35
    elif symbol == 'Kr':
        znucl=36
    elif symbol == 'Rb':
        znucl=37
    elif symbol == 'Sr':
        znucl=38
    elif symbol == ' Y' or symbol == 'Y ':
        znucl=39    
    elif symbol == 'Zr':
        znucl=40
    elif symbol == 'Nb':
        znucl=41
    elif symbol == 'Mo':
        znucl=42
    elif symbol == 'Tc':
        znucl=43
    elif symbol == 'Ru':
        znucl=44
    elif symbol == 'Rh':
        znucl=45
    elif symbol == 'Pd':
        znucl=46
    elif symbol == 'Ag':
        znucl=47
    elif symbol == 'Cd':
        znucl=48
    elif symbol == 'In':
        znucl=49
    elif symbol == 'Sn':
        znucl=50
    elif symbol == 'Sb':
        znucl=51
    elif symbol == 'Te':
        znucl=52
    elif symbol == ' I' or symbol == 'I ':
        znucl=53
    elif symbol == 'Xe':
        znucl=54
    elif symbol == 'Cs':
        znucl=55
    elif symbol == 'Ba':
        znucl=56
    elif symbol == 'La':
        znucl=57
    elif symbol == 'Ce':
        znucl=58
    elif symbol == 'Pr':
        znucl=59
    elif symbol == 'Nd':
        znucl=60
    elif symbol == 'Pm':
        znucl=61
    elif symbol == 'Sm':
        znucl=62
    elif symbol == 'Eu':
        znucl=63
    elif symbol == 'Gd':
        znucl=64
    elif symbol == 'Tb':
        znucl=65
    elif symbol == 'Dy':
        znucl=66
    elif symbol == 'Ho':
        znucl=67
    elif symbol == 'Er':
        znucl=68
    elif symbol == 'Tm':
        znucl=69
    elif symbol == 'Yb':
        znucl=70
    elif symbol == 'Lu':
        znucl=71
    elif symbol == 'Hf':
        znucl=72
    elif symbol == 'Ta':
        znucl=73
    elif symbol == ' W' or symbol == 'W ':
        znucl=74
    elif symbol == 'Re':
        znucl=75
    elif symbol == 'Os':
        znucl=76
    elif symbol == 'Ir':
        znucl=77
    elif symbol == 'Pt':
        znucl=78
    elif symbol == 'Au':
        znucl=79
    elif symbol == 'Hg':
        znucl=80
    elif symbol == 'Tl':
        znucl=81
    elif symbol == 'Pb':
        znucl=82
    elif symbol == 'Bi':
        znucl=83
    elif symbol == 'Po':
        znucl=84
    elif symbol == 'At':
        znucl=85
    elif symbol == 'Rn':
        znucl=86
    elif symbol == 'Fr':
        znucl=87
    elif symbol == 'Ra':
        znucl=88
    elif symbol == 'Ac':
        znucl=89
    elif symbol == 'Th':
        znucl=90
    elif symbol == 'Pa':
        znucl=91
    elif symbol == ' U' or symbol == 'U ':
        znucl=92
    elif symbol == 'Np':
        znucl=93
    elif symbol == 'Pu':
        znucl=94
    elif symbol == 'Am':
        znucl=95
    elif symbol == 'Cm':
        znucl=96
    elif symbol == 'Bk':
        znucl=97
    elif symbol == 'Cf':
        znucl=98
    elif symbol == 'Es':
        znucl=89
    elif symbol == 'Fm':
        znucl=100
    elif symbol == 'Md':
        znucl=101
    elif symbol == 'No':
        znucl=102
    elif symbol == 'Lr':
        znucl=103
    elif symbol == 'Xx':
        znucl=104
    else:
        print("Unknown symbol name: ${symbol}")
        print('out of range')

    return znucl

#----------------
def atmdata(znucl, optdata='ase'):
    """Return atomic data : $symbol, covalent radius, atomic mass
    This is based on atmdata.F90 in abinit-5.8.4"""
    Bohr_Ang = 0.52917720859

    atomic_masses_abinit_5_8_4 = [
        1.0,         # no
        1.00794,     # H
        4.002602,    # He
        6.941,       # Li
        9.012182,    # Be
        10.811,      # B
        12.011,      # C
        14.00674,    # N
        15.9994,     # O
        18.9984032,  # F
        20.1797,     # Ne
        22.989768,   # Na
        24.3050,     # Mg
        26.981539,   # Al
        28.0855,     # Si
        30.973762,   # P
        32.066,      # S
        35.4527,     # Cl
        39.948,      # Ar
        39.0983,     # K
        40.078,      # Ca
        44.955910,   # Sc
        47.88,       # Ti
        50.9415,     # V
        51.9961,     # Cr
        54.93805,    # Mn
        55.847,      # Fe
        58.93320,    # Co
        58.69,       # Ni
        63.546,      # Cu
        65.39,       # Zn
        69.723,      # Ga
        72.61,       # Ge
        74.92159,    # As
        78.96,       # Se
        79.904,      # Br
        83.80,       # Kr
        85.4678,     # Rb
        87.62,       # Sr
        88.90585,    # Y
        91.224,      # Zr
        92.90638,    # Nb
        95.94,       # Mo
        98.9062,     # Tc
        101.07,      # Ru
        102.9055,    # Rh
        106.42,      # Pd
        107.8682,    # Ag
        112.411,     # Cd
        114.82,      # In
        118.710,     # Sn
        121.753,     # Sb
        127.60,      # Te
        126.90447,   # I
        131.29,      # Xe
        132.90543,   # Cs
        137.327,     # Ba
        138.9055,    # La
        140.115,     # Ce
        140.90765,   # Pr
        144.24,      # Nd
        147.91,      # Pm
        150.36,      # Sm
        151.965,     # Eu
        157.25,      # Gd
        158.92534,   # Tb
        162.50,      # Dy
        164.93032,   # Ho
        167.26,      # Er
        168.93421,   # Tm
        173.04,      # Yb
        174.967,     # Lu
        178.49,      # Hf
        180.9479,    # Ta
        183.85,      # W
        186.207,     # Re
        190.2,       # Os
        192.22,      # Ir
        195.08,      # Pt
        196.96654,   # Au
        200.59,      # Hg
        204.3833,    # Tl
        207.2,       # Pb
        208.98037,   # Bi
        209.0,       # Po
        210.0,       # At
        222.0,       # Rn
        223.0,       # Fr
        226.0254,    # Ra
        230.0,       # Ac
        232.0381,    # Th
        231.0359,    # Pa
        238.0289,    # U
        237.0482,    # Np
        242.0,       # Pu
        243.0,       # Am
        247.0,       # Cm
        247.0,       # Bk
        249.0,       # Cf
        254.0,       # Es
        253.0,       # Fm
        256.0,       # Md
        254.0,       # No
        257.0,       # Lr
        260.0,       # Xx 
    ]

    covalent_radii_abinit_5_8_4 = [
        1.0,   #  no
        0.32,  #  H
        0.93,  #  He
        1.23,  #  Li
        0.90,  #  Be
        0.80,  #  B
        0.77,  #  C
        0.74,  #  N
        0.73,  #  O
        0.72,  #  F
        0.71,  #  Ne
        1.54,  #  Na
        1.36,  #  Mg
        1.18,  #  Al
        1.11,  #  Si
        1.06,  #  P
        1.02,  #  S
        0.99,  #  Cl
        0.98,  #  Ar
        2.03,  #  K
        1.74,  #  Ca
        1.44,  #  Sc
        1.32,  #  Ti
        1.22,  #  V
        1.18,  #  Cr
        1.17,  #  Mn
        1.17,  #  Fe
        1.16,  #  Co
        1.15,  #  Ni
        1.17,  #  Cu
        1.25,  #  Zn
        1.26,  #  Ga
        1.22,  #  Ge
        1.20,  #  As
        1.16,  #  Se
        1.14,  #  Br 
        1.12,  #  Kr
        2.16,  #  Rb
        1.91,  #  Sr
        1.62,  #  Y
        1.45,  #  Zr
        1.34,  #  Nb
        1.30,  #  Mo
        1.27,  #  Tc
        1.25,  #  Ru
        1.25,  #  Rh
        1.28,  #  Pd
        1.34,  #  Ag
        1.48,  #  Cd
        1.44,  #  In
        1.41,  #  Sn
        1.40,  #  Sb
        1.36,  #  Te
        1.33,  #  I
        1.31,  #  Xe
        2.35,  #  Cs
        1.98,  #  Ba
        1.69,  #  La
        1.65,  #  Ce
        1.65,  #  Pr
        1.64,  #  Nd
        1.64,  #  Pm
        1.62,  #  Sm
        1.85,  #  Eu
        1.61,  #  Gd
        1.59,  #  Tb
        1.59,  #  Dy
        1.57,  #  Ho
        1.57,  #  Er
        1.56,  #  Tm
        1.70,  #  Yb
        1.56,  #  Lu
        1.44,  #  Hf
        1.34,  #  Ta
        1.30,  #  W
        1.28,  #  Re
        1.26,  #  Os
        1.27,  #  Ir
        1.30,  #  Pt
        1.34,  #  Au
        1.49,  #  Hg
        1.48,  #  Tl
        1.47,  #  Pb
        1.46,  #  Bi
        1.46,  #  Po
        1.45,  #  At
        1.45,  #  Rn
        2.50,  #  Fr
        2.10,  #  Ra
        1.85,  #  Ac
        1.65,  #  Th
        1.50,  #  Pa
        1.42,  #  U
        1.42,  #  Np
        1.42,  #  Pu
        1.42,  #  Am
        1.42,  #  Cm
        1.42,  #  Bk
        1.42,  #  Cf
        1.42,  #  Es
        1.42,  #  Fm
        1.42,  #  Md
        1.42,  #  No
        1.42,  #  Lr
        1.42,  #  Xx
    ]

    symbols = [
        # 0
        'no',
        # 1
        ' H', 'He',
        # 2
        'Li', 'Be', ' B', ' C', ' N', ' O', ' F', 'Ne',
        # 3
        'Na', 'Mg', 'Al', 'Si', ' P', ' S', 'Cl', 'Ar',
        # 4
        ' K', 'Ca', 'Sc', 'Ti', ' V', 'Cr', 'Mn', 'Fe', 'Co', 'Ni', 'Cu', 'Zn',
        'Ga', 'Ge', 'As', 'Se', 'Br', 'Kr',
        # 5
        'Rb', 'Sr', ' Y', 'Zr', 'Nb', 'Mo', 'Tc', 'Ru', 'Rh', 'Pd', 'Ag', 'Cd',
        'In', 'Sn', 'Sb', 'Te', ' I', 'Xe',
        # 6
        'Cs', 'Ba', 'La', 'Ce', 'Pr', 'Nd', 'Pm', 'Sm', 'Eu', 'Gd', 'Tb', 'Dy',
        'Ho', 'Er', 'Tm', 'Yb', 'Lu',
        'Hf', 'Ta', 'W', 'Re', 'Os', 'Ir', 'Pt', 'Au', 'Hg', 'Tl', 'Pb', 'Bi',
        'Po', 'At', 'Rn',
        # 7
        'Fr', 'Ra', 'Ac', 'Th', 'Pa', ' U', 'Np', 'Pu', 'Am', 'Cm', 'Bk',
        'Cf', 'Es', 'Fm', 'Md', 'No', 'Lr',
        'Rf', 'Db', 'Sg', 'Bh', 'Hs', 'Mt', 'Ds', 'Rg', 'Cn', 'Nh', 'Fl', 'Mc',
        'Lv', 'Ts', 'Og']

    print("atmdata: optdata=",optdata)
 
    if optdata == 'abinit_5_8_4':
        atomic_masses = atomic_masses_abinit_5_8_4
        covalent_radii = covalent_radii_abinit_5_8_4

    elif optdata == 'ase':
        import ase
        from ase import data
        print("ase versiion=",ase.__version__)
        atomic_masses = data.atomic_masses.tolist()
        covalent_radii = data.covalent_radii.tolist()

    else:
        print('out of range')

    amu = atomic_masses[znucl]
    rcov = covalent_radii[znucl]
    symbol = symbols[znucl]

    return [amu,rcov,symbol]

#----------------------------------
# Convert symbols[natom] to typat[natom]
# This script is based on ase2inp.py

def gettypat(symbol):
  nwrite = 0  # do not write except for POSCAR 
#  nwrite = 1  # write info other than POSCAR
  natom = len(symbol)

  # deduce ntypat from symbol[natom]
  symbol1=sorted(symbol)
  ntypat=1
  s1=symbol1[0]
  for i in range(natom):
    s2=symbol1[i] 
    if nwrite == 1: print(s1,s2)
    if s2 != s1:
      ntypat = ntypat + 1
      s1=s2
#  if nwrite == 1: print("ntypat = ",ntypat)
#  sys.exit() 

# decide typat, symboltypat, nattyp
# This part is based on Work_lammps/xsf2lmp.py(20170224)
  typat=[-1 for i in range(natom)]
  nattyp=[0 for i in range(ntypat)]
  symboltypat=[0 for i in range(ntypat)]
  znucl=[0 for i in range(ntypat)]

  for itypat in range(ntypat):
    nattyp[itypat] = 0
    symboltypat[itypat] = 0

    for iat in range(natom):
      atomsymbol = symboltypat[itypat]

      if typat[iat] == -1:

        if atomsymbol == 0:
          typat[iat] = itypat
          nattyp[itypat] = nattyp[itypat] + 1
          symboltypat[itypat] = symbol[iat]
          znucl[itypat] = symbol2znucl(symbol[iat])

        elif symbol[iat] == atomsymbol:
          typat[iat] = itypat
          nattyp[itypat] = nattyp[itypat] + 1

  return ntypat,typat,nattyp,symboltypat,znucl
#----------------------------------------------


if __name__ == "__main__":
    import sys

    if len(sys.argv) == 1:
        print("option:")
        print("-o: abinit or ase")
        print("example: atmdata.py 6 -o ase")
        sys.exit()

    optdata = 'ase'  # default is ase

    argvs = sys.argv   # get list which contains arguments
    argc = len(argvs)  # number of arguments

    ic = 1
    znucl = int(argvs[1])
    ic = ic + 1
    print("znucl=",str(znucl))
    while (ic < argc):
    # type of database
        if ic < argc and argvs[ic] == '-o':
            ic = ic + 1
            optdata = argvs[ic]
            ic = ic + 1

    print("optdata=",optdata)
    if optdata == 'abinit':
        optdata = 'abinit_5_8_4'
        print("full_optdata=",optdata)

    amu, rcov, symbol = atmdata(znucl,optdata)
    print(str(amu)+' '+str(rcov)+' '+str(symbol))

