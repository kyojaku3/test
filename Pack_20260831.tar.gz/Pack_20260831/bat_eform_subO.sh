#!/bin/bash

bulk_dir=$1
defect_dir=$2
mol_dir_str=$3
elem_str=$4  # O,F
nmol=$5

IFSbak=$IFS
# mol_dir_str
IFS=, mol_dir_arr=(${mol_dir_str}); IFS=$IFSbak
echo ${mol_dir_arr[@]}

# elem_str
IFS=, elem_arr=(${elem_str}); IFS=$IFSbak
echo ${elem_arr[@]}
nelem=${#elem_arr[@]}
echo "nelem = $nelem"
#exit

# Atomization energies of homonuclear diatomic molecule in PRL1996Perdew
declare -A atomization_energies=( ["H"]=109 ["Li"]=24 ["N"]=229 ["O"]=121 ["F"]=39 ["P"]=117 ["Cl"]=58 )

function get_energy(){
  outdir=$1
  if [ ! -f "${outdir}/vasprun.xml" ]; then
    echo "error"
    return 1
  fi

  read etotal natom < <(./ve.sh ${outdir}/vasprun.xml | awk '{print $1, $3}')

  echo $etotal $natom
}

read e_bulk natom < <(get_energy $bulk_dir)
echo $e_bulk

declare -A e_elem
declare -A e_elem_dft
declare -A e_elem_exp
for((iel=0;iel<$nelem;iel++)); do
  elem=${elem_arr[$iel]}
  mol_dir=${mol_dir_arr[$iel]}
  read etotal natom < <(get_energy $mol_dir)
  e_elem_dft[$elem]=$(echo "scale=16; $etotal / $natom" | bc)
  echo ${e_elem_dft[$elem]}
  KCalbyMol_eV=0.0433641008036641  # $ gnuplot -e "load 'param.gp'; print KCalbyMol_eV"

  if [[ ${atomization_energies[$elem]:+exists} ]]; then
    e_elem_exp[$elem]=${atomization_energies[$elem]}
    echo "$elem exist in atomization_energies with values: $e_elem_exp"
    e_elem[$elem]=$(echo "2 * ${e_elem_dft[$elem]} - ${e_elem_exp[$elem]} * $KCalbyMol_eV" | bc)
    e_elem[$elem]=$(echo "scale=16; ${e_elem[$elem]} / 2" | bc)
    echo "Corrected energy = ${e_elem[$elem]} [eV/atom]"
  else
    echo "$elem does not exist in atomization_energies."
    e_elem_exp[$elem]="None"
    e_elem[$elem]=${e_elem_dft[$elem]}
  fi
done
#exit

out_path="${defect_dir}/eform.dat"
echo "output file = $out_path"

echo "# e_bulk=$e_bulk, bulk_dir=$bulk_dir" > $out_path
echo "# e_elem_dft=${e_elem_dft[@]}, mol_dir=${mol_dir_arr[@]}" >> $out_path
echo "# e_elem_exp(kCal/mol)=${e_elem_exp[@]}, e_elem=${e_elem[@]}" >> $out_path
echo "idx  e_defect  e_form" >> $out_path

elem1=${elem_arr[0]}
elem2=${elem_arr[1]}
for((idx=1;idx<=$nmol;idx++)); do
  echo -n "$idx "
  outdir="$defect_dir/$idx/relax"
  read e_defect natom < <(get_energy $outdir)
  e_int=$(echo "$e_defect + ${e_elem[$elem1]} - $e_bulk - ${e_elem[$elem2]}" | bc -l)
  echo "$idx $e_defect $e_int" >> $out_path
done
echo "finished"

