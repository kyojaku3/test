#!/bin/bash

ipr_vasp="$HOME/tools/ForVASP/Pymatgen/IPR_kawai/ipr_vasp"
HLgap_IPR="$HOME/tools/ForVASP/Pymatgen/IPR_kawai/HLgap_IPR.csh"
dosipr_gp="$(pwd)/dosipr.gp"

nscf_dir=$1
cd $nscf_dir

if [ ! -e IPRraw.dat ]; then
  $ipr_vasp
fi

n_atoms=$(awk 'NR==2{print $NF}' PROCAR)
IPRth=$(echo 3 / $n_atoms | bc -l)
$HLgap_IPR $IPRth

ef=$(awk 'NR==6{print $4}' DOSCAR)
gnuplot -persist -e Efermi=$ef $dosipr_gp

