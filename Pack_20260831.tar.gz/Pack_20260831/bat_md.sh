#!/bin/bash

work_dir=$1
nproc=$2
echo "work_dir=$work_dir, nproc=$nproc"

vaspmpset=$(realpath "../Pymatgen/vaspmpset.py")
mkrandstr=$(realpath "master/mkrandstr.py")

test ! -e $work_dir && mkdir $work_dir
cp -p incar_ldau.yaml $work_dir
cp -p $0 $work_dir
cd $work_dir


python3 $mkrandstr In,Ga,Zn,O 16,24,8,68 1 5.9 POSCAR

#python3 $vaspmpset POSCAR md None 1 -incar \
#  '{"ENCUT":400,"ALGO":"Normal","POTIM":4.0,\
#  "TEBEG":5000,"TEEND":5000,"NSW":250}' \
#  --ensemble nvt -y incar_ldau.yaml -r false

python3 $vaspmpset POSCAR md None $nproc -incar '{
  "ENCUT":400,
  "ALGO":"Normal",
  "POTIM":4.0,
  "TEBEG":5000,
  "TEEND":5000,
  "NSW":250
}' -kpt 'Kpoints.gamma_automatic((1,1,1))' \
--ensemble nvt -y incar_ldau.yaml -o melt_nvt -v vasp_gam


python3 $vaspmpset melt_nvt/CONTCAR md None $nproc -incar '{
  "ENCUT":400,
  "ALGO":"Normal",
  "POTIM":4.0,
  "TEBEG":5000,
  "TEEND":1000,
  "NSW":400
}' -kpt 'Kpoints.gamma_automatic((1,1,1))' \
--ensemble nvt -y incar_ldau.yaml -o quench_nvt -v vasp_gam


python3 $vaspmpset quench_nvt/CONTCAR md None $nproc -incar '{
  "ENCUT":400,
  "ALGO":"Normal",
  "POTIM":4.0,
  "TEBEG":1000,
  "TEEND":0,
  "NSW":100
}' -kpt 'Kpoints.gamma_automatic((1,1,1))' \
--ensemble npt -o quench_npt -v vasp_gam


python3 "$vaspmpset" quench_npt/CONTCAR relax None $nproc -incar '{
  "ENCUT":500,
  "ALGO":"Normal",
  "NSW":300
}' -kpt 'Kpoints.gamma_automatic((1,1,1))' \
-o relax -v vasp_gam

