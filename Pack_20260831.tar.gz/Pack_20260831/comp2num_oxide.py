#!/usr/bin/env python3

import sys, os
import argparse
import numpy as np


def calc_natoms(comp: np.array, oxi: np.array, scale=1.0):
    ref_idx = np.nonzero(comp)[0][0]
    n_cations_arr = comp/comp[ref_idx]*scale  # cation
    n_O = 0.5*np.sum(comp*oxi)/comp[ref_idx]*scale  # oxygen
    n_atoms_arr = np.append(n_cations_arr, n_O)
    n_atoms = np.sum(n_atoms_arr)
#    print(n_atoms)
    for val in n_atoms_arr:
        if (val - int(val)) > 1e-5:
            return None
    n_atoms_arr = n_atoms_arr.astype(int)
    return n_atoms_arr


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Calculate the number of cation atoms in oxides with stoichiometric composition from the cation composition ratio")
    parser.add_argument("-comp", "--comp_list", type=int, nargs='+')
    parser.add_argument("-oxi", "--oxi_list", type=int, nargs='+')
    parser.add_argument("-min", "--min_atoms", type=int, default=100)
    parser.add_argument("-max", "--max_atoms", type=int)

    args = parser.parse_args()
    comp = np.array(args.comp_list)
    oxi = np.array(args.oxi_list)
    print("Input:")
    print("comp= ", *comp)
    print("oxi= ", *oxi)
    print(f"min={args.min_atoms}, max={args.max_atoms}")

#    is_check = True
    is_check = False
    if is_check:
#        scale = 16
        scale = 32
        n_atoms_arr = calc_natoms(comp, oxi, scale)
        n_atoms = int(np.sum(n_atoms_arr))
        print(n_atoms)
        print(n_atoms_arr)
        sys.exit()

    print("Output:")
    for i in range(1,101):        
        n_atoms_arr = calc_natoms(comp, oxi, i)
        n_atoms = np.sum(n_atoms_arr)
#        print(i, n_atoms_arr, n_atoms)
        if not n_atoms:
            continue

        if n_atoms >= args.min_atoms:
            if args.max_atoms:
                if n_atoms > args.max_atoms:
                    break
            else:
                print(i, n_atoms_arr, n_atoms)
                break

    print("comp= ", *n_atoms_arr)

