#!/bin/bash

vaspmpset="$HOME/tools/ForVASP/Pymatgen/vaspmpset.py"

work_dir=$1
poscar_file=$2
dopesymbol=$3
nproc=$4
mode=$5  # all, range, random
arg1=$6
arg2=$7
seed=12345
queue=q1

echo "work_dir=$work_dir"
echo "mode = $mode"
poscar_filepath=$(realpath $poscar_file)
echo "poscar_filepath=$poscar_filepath"

test ! -e $work_dir && mkdir $work_dir
cp -p incar_ldau.yaml $work_dir

poscar_file=$(basename $poscar_filepath)
cp -p $poscar_filepath $work_dir
cp -p $0 $work_dir

pwd_dir=$(pwd)
cd $work_dir

O_indices=($(ase convert $poscar_file tmp.vasp -f \
 -e "print([idx for idx,elem in enumerate(atoms.get_chemical_symbols()) if elem=='O'])" \
| sed -e "s/,//g" | sed -e "s/\[//g" | sed -e "s/\]//g"))

n_O=${#O_indices[@]}
echo "number of O atoms = $n_O"

case "$mode" in
  all)
    echo "Mode: ALL -> all pattern"
    selected_indices=("${O_indices[@]}")
    ;;

  range)
    idx_start=$arg1
    idx_end=$arg2
    test $(echo "$idx_start < 1" | bc) -eq 1 && idx_start=1
    test $(echo "$idx_end > $n_O" | bc) -eq 1 && idx_end=$n_O
    echo "Mode: RANGE -> idx=$idx_start ~ $idx_end"

    selected_indices=()
    for ((i=idx_start; i<=idx_end; i++)); do
        selected_indices+=("${O_indices[$i-1]}")
    done
    ;;

  random)
    n_pattern=$arg1
    echo "Mode: RANDOM -> n_pattern=$n_pattern, seed=$seed"

    if [ $n_pattern -ge $n_O ]; then
        echo "n_pattern >= $n_O -> switch all pattern"
        selected_indices=("${O_indices[@]}")
    else
        selected_indices=($(printf "%s\n" "${O_indices[@]}" | \
            shuf -n $n_pattern --random-source=<(yes $seed)))
    fi
    ;;

  *)
    echo "Error: mode should be all / range / random"
    exit 1
    ;;
esac

echo "Selected O indices: ${selected_indices[@]}"

count=1
for idx_O in "${selected_indices[@]}"; do
  echo "Processing defect #$count (O index = $idx_O)"

  dir=$count
  test ! -e $dir && mkdir $dir

  if [ -e $dir/relax/vasprun.xml ]; then
      echo "Skip: $dir already finished"
      count=$((count+1))
      continue
  fi

  if [ ! -e $dir/POSCAR ]; then
    ase convert $poscar_file $dir/POSCAR -f -e "atoms[$idx_O].symbol='$dopesymbol'; atoms.rattle(stdev=0.1,seed=12345)"
  fi

  pwd_dir2=$(pwd) 
  cd $dir

  cat << EOF >> vaspmpset.sh
python3 $vaspmpset POSCAR relax None $nproc -incar '{
  "ENCUT":500,
  "ALGO":"Normal",
  "NSW":10000
}' -kpt 'Kpoints.gamma_automatic((1,1,1))' \
-y ../incar_ldau.yaml -o relax -v vasp_gam
EOF
  chmod +x vaspmpset.sh
  echo "source ~/setbash.sh; cd $(pwd); bash ./vaspmpset.sh" | qsub -q $queue -N ${work_dir}_${dir} -l select=1:ncpus=$nproc -o lsf.log
  sleep 1
  cd $pwd_dir2
  count=$((count+1))
#  exit
done

cd $pwd_dir

