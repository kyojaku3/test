#!/bin/bash

#. ~/setbash.sh  # include 'load init'
. ~/setbash.sh 0
module load init

module list

