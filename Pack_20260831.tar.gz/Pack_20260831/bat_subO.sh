#!/bin/bash

dopesymbol=$1  # F, Cl
shift 1

work_dir=work
queue="q18a_fs"
while getopts "d:q:" opt; do
  case $opt in
    d) work_dir="$OPTARG" ;;
    q) queue="$OPTARG" ;;
    \?) echo "Invalid option -$OPTARG" >&2
    ;;
  esac
done
echo "dopesymbol=$dopesymbol"
echo "work_dir=$work_dir, queue=$queue"

test ! -e $work_dir && echo "$work_dir does not exist." && exit
test ! -e $work_dir/incar_ldau.yaml && echo "$work_dir/incar_ldau.yaml does not exist." && exit
cp -p calc_subO_para.sh $work_dir
cp -p $0 $work_dir
cd $work_dir

./calc_subO_para.sh ${dopesymbol}o relax/CONTCAR 8 -1 1000 $queue

