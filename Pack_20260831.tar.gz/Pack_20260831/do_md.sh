#! /bin/bash
# ini:20201017, update:20210619

LSF_TYPE="qsub"
LSF_QUEUE="q1" 
#LSF_TYPE="bsub"
#LSF_QUEUE="q18a_fs" 

JOB_NAME='test_md'

while getopts ":n:d:j:" opt; do
  case $opt in
    n) np="$OPTARG" ;;
    d) workdir="$OPTARG" ;;
    j) JOB_NAME="$OPTARG" ;;
    \?) echo "Invalid option -$OPTARG" >&2
    ;;
  esac
done

np_node=$np
test $np -gt 24 && np_node=24

is_relax=true
#is_relax=false
master="./master"
project="PROJECT"

if [ -e $workdir ]; then
  echo "$workdir directory exists !!"
#  exit 1
else
  mkdir $workdir
  cp -r $master $workdir
fi
cp $0 $workdir
cd $workdir


lsf_run() {
  if [ $LSF_TYPE = "qsub" ]; then
    qsub -d `pwd` -q $LSF_QUEUE -N $JOB_NAME -l nodes=1:ppn=$np -o log -v "np=$np,is_relax=$is_relax" do.sh
  elif [ $LSF_TYPE = "bsub" ]; then
    bsub -q $LSF_QUEUE -J $JOB_NAME -n $np -R span[ptile=$np_node] -o log bash do.sh $np $is_relax
  fi
}

(cp -r $master $project; \
cd $project; \
lsf_run)&
sleep 1


