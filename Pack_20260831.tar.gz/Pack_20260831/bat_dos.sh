#!/bin/bash

vaspmpset="$HOME/tools/ForVASP/Pymatgen/vaspmpset.py"

work_dir=$1
nproc=$2

echo "work_dir=$work_dir"
cd $work_dir

ecut=500

# 4. SCF(PBEU)
python3 $vaspmpset relax/CONTCAR scf None $nproc -incar '{
  "ENCUT":'$ecut',
  "ALGO":"Normal"
}' -kpt 'Kpoints.gamma_automatic((1,1,1))' \
-y ../incar_ldau.yaml -o scf -v vasp_gam

# 5. NSCF(PBEU)
python3 $vaspmpset relax/CONTCAR nscf scf $nproc -incar '{
  "ENCUT":'$ecut',
  "ALGO":"Normal"
}' -kpt 'Kpoints.gamma_automatic((2,2,2))' \
-y ../incar_ldau.yaml --project_lm true -o nscf -v vasp_std

