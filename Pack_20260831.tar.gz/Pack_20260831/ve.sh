#!/bin/bash

vfile=$1
etotal_and_natom=$(python3 -c "from pymatgen.io.vasp import Vasprun; v=Vasprun('$vfile', parse_dos=True, parse_eigen=True, parse_projected_eigen=False, parse_potcar_file=False); print(v.final_energy, len(v.final_structure))")
echo $etotal_and_natom
