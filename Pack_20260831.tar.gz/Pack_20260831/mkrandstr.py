#!/bin/env python3
# ini:20210613, update:20250612

import os
import shutil
import subprocess
import sys
import ase
from ase.io import read,write
from ase import Atoms
from atmdata import symbol2znucl, atmdata, gettypat
from monty.os import cd

class packmol:
    def __init__(self, composition, nunit, symboltypat, typat):
        self.composition = composition
        self.nunit = nunit
        self.symboltypat = symboltypat
        self.typat = typat

    def make_input(self, alat,
                   filinp="packmol.inp", 
                   user_inpvars=None,
                   seed=12345):
        self.filinp = filinp
        ntypat = len(self.composition)

        inpvars = {}

        inpvars.update({
  "tolerance": 2.0,
  "filetype": "xyz",
  "output": "packmol.xyz",
  "seed": seed,
        })

        if user_inpvars != None:
            inpvars.update(user_inpvars)

        f = open(filinp, 'w')
        for key,val in inpvars.items():
            print(key," ",val, file=f)
        print("", file=f)
        for itypat in range(ntypat):
            filxyz2 = self.symboltypat[itypat] + ".xyz"

            atom = Atoms(self.symboltypat[itypat], positions=[(0.0, 0.0, 0.0)])
            atom.write(filxyz2)

            print("structure ", filxyz2, file=f)
            print("  number ", self.nunit*self.composition[itypat], file=f)
            print("  inside box 0.0 0.0 0.0 %15.10f %15.10f %15.10f" % (alat, alat, alat), file=f)
            print("end structure", file=f)
            print("",file=f)     


    def run(self, outdir, 
            PACKMOL_CMD=['packmol < packmol.inp > packmol.out 2>&1']):
        print(' '.join(PACKMOL_CMD))
        subprocess.call("cd " + outdir + "; " + ' '.join(PACKMOL_CMD), shell=True)


    def xyz2pbc(self, alat,
                filxyz="packmol.xyz", 
                filout="packmol.xsf"):

        tmpxyz = "tmp.xyz" 
        f = open(filxyz, 'r')
        datalist = f.readlines()
        f.close()

        n = len(datalist)
        datalist[1] = "Lattice = '" + str(alat) + " 0 0 0 " + str(alat) + " 0 0 0 " + str(alat) + "' Properties=species:S:1:pos:R:3 pbc='T T T'\n"
        f = open(tmpxyz, 'w')
        f.write(datalist[0])
        f.write(datalist[1])
        for i in range(2,n):
            f.write(datalist[i])
        f.close()

        CMD=['ase convert ' + tmpxyz + ' ' + filout + ' -f > log-conv 2>&1']

        print(' '.join(CMD))
        subprocess.call("cd " + outdir + "; " + ' '.join(CMD), shell=True)


class xatoms:
    def __init__(self, atoms, ntypat):
        self.atoms = atoms
        self.ntypat = ntypat

        self.natom=atoms.get_global_number_of_atoms()
        self.ucvol=atoms.get_volume()
        self.symbols=atoms.get_chemical_symbols()

        # typat,ntypat
        self.ntypat,self.typat,self.nattyp,self.symboltypat,self.znucltypat = gettypat(self.symbols)
        print('typat='+str(self.typat))

        # amu
        self.amu=[0 for i in range(self.ntypat)]
        for itypat in range(self.ntypat):
            [self.amu[itypat], rcov, symbol] = atmdata(self.znucltypat[itypat], optdata='ase')
            print(str(self.amu[itypat])+' '+str(rcov)+' '+str(symbol))

    # Calculate current density in g/cm3                
    def get_density(self):
        molmass = 0;
        for iat in range(self.natom):
            itypat = self.typat[iat]
            molmass = molmass + self.amu[itypat];
        print('molmass (g/mol) = '+str(molmass))
        factor = 10.0/6.02214179;
        density = molmass/self.ucvol*factor;

        return density


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("symbol_str", type=str)
    parser.add_argument("composition_str", type=str)
    parser.add_argument("nunit", type=int)
    parser.add_argument("target_density", type=float)
    parser.add_argument("filout", type=str)
    parser.add_argument("--seed", type=int, default=12345)

    args = parser.parse_args()
    symbol_str = args.symbol_str
    composition_str = args.composition_str
    nunit = args.nunit
    target_density = args.target_density
    filout = args.filout
    seed = args.seed

    print("ase versiion=",ase.__version__)

    symboltypat = symbol_str.split(',')
    composition = [int(z) for z in composition_str.split(',')]
    print("symboltypat = ",symboltypat)
    print("composition = ",composition)
    print("nunit = ",nunit)
    print("target_density = ",target_density)
    print("filout = ",filout)
    print("seed = ",seed)

    ntypat = len(symboltypat)
    natom_unit = sum(composition)
    natom = natom_unit * nunit
    print("ntypat = ",ntypat)
    print("natom_unit = ",natom_unit)
    print("natom = ",natom)

    znucltypat=[0 for i in range(ntypat)]
    for itypat in range(ntypat):
        znucltypat[itypat] = symbol2znucl(symboltypat[itypat])
    print("znucltypat = ",znucltypat)

    amu=[0 for i in range(ntypat)]
    rcov=[0 for i in range(ntypat)]
    for itypat in range(ntypat):
        [amu[itypat],rcov[itypat],symbol] = atmdata(znucltypat[itypat], optdata='ase')
        print(str(amu[itypat])+' '+str(rcov[itypat])+' '+str(symbol))

    typat_unit=[0 for i in range(natom_unit)]
    iatom = 0
    for itypat in range(ntypat):
        for i in range(composition[itypat]):
            typat_unit[iatom] = itypat
            iatom = iatom + 1
    typat = typat_unit * nunit
    print("typat_unit = ",typat_unit)
#    print("typat = ",typat)

    molmass = 0;
    for iat in range(natom):
        molmass = molmass + amu[typat[iat]]
    print('molmass (g/mol) = '+str(molmass))
    factor = 10.0/6.02214179;
    ucvol = molmass/target_density*factor
    alat = ucvol**(1./3.)
    print("alat = ",alat)

    density = molmass/ucvol*factor
    print("density = ",density)

    user_inpvars={}
    user_inpvars.update({"tolerance": 2.0})

    packmol = packmol(composition, nunit, symboltypat, typat)

    alat2 = alat - user_inpvars["tolerance"]
    packmol.make_input(alat2,
                       filinp="packmol.inp", 
                       user_inpvars=user_inpvars,
                       seed=seed)

    outdir = './'

    mkjobscript='mkqsub_colnago.sh'
    queue='q1'
    jobname='test'
    nproc=1
    PACKMOL_COMMAND = 'packmol < packmol.inp > packmol.out 2>&1'
    PACKMOL_CMD = [mkjobscript, jobname, queue, str(nproc), '"', PACKMOL_COMMAND, '"', str(0), str(1)]

    packmol.run(outdir)
#    packmol.run(outdir, PACKMOL_CMD)

    packmol.xyz2pbc(alat, filout=filout)

#    filstruct = 'packmol.xsf' 
#    filstruct = 'test.xsf' 
#    cryst = read(filstruct)
#    xcryst = xatoms(cryst, ntypat)
#    print(xcryst.get_density())

