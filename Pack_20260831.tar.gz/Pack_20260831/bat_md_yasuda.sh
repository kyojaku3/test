#!/bin/bash

cIn=$1
cGa=$2
cZn=$3
shift 3

work_dir=work
nproc=1
seed=12345
while getopts "d:n:s:" opt; do
  case $opt in
    d) work_dir="$OPTARG" ;;
    n) nproc="$OPTARG" ;;
    s) seed="$OPTARG" ;;
    \?) echo "Invalid option -$OPTARG" >&2
    ;;
  esac
done
echo "cIn=$cIn, cGa=$cGa, cZn=$cZn"
echo "work_dir=$work_dir, nproc=$nproc"
echo "seed=$seed"

vaspmpset="$HOME/tools/ForVASP/Pymatgen/vaspmpset.py"
mkrandstr=$(realpath "./mkrandstr.py")
comp2num=$(realpath "./comp2num_oxide.py")

test ! -e $work_dir && mkdir $work_dir
cp -p incar_ldau.yaml $work_dir
cp -p calc_Vo_para.sh $work_dir
cp -p $0 $work_dir
cd $work_dir

#ecut_md=500; ecut=500
ecut_md=400; ecut=400
echo "ecut_md=$ecut_md, ecut=$ecut"

#do_md=0
do_md=1
#do_relax=0
do_relax=1
do_Vo=0
#do_Vo=1

if [ $do_md -eq 1 ];then
echo "do MD"

natom_str=$(python3 $comp2num -comp $cIn $cGa $cZn -oxi 3 3 2 -min 110 \
| tail -n1 | awk -v OFS=, '{print $2,$3,$4,$5}')
echo $comp_str
python3 $mkrandstr In,Ga,Zn,O $natom_str 1 5.9 POSCAR --seed $seed
#exit

#dt=2.0; nstep=(1001 2601)
#dt=4.0; nstep=(251 501)
dt=4.0; nstep=(101 251)
echo "dt=$dt, nstep=${nstep[@]}"

# 1. Melt(NVT, PBEU)
python3 $vaspmpset POSCAR md None $nproc -incar '{
  "ENCUT":'$ecut_md',
  "ALGO":"Normal",
  "POTIM":'$dt',
  "TEBEG":5000,
  "TEEND":5000,
  "NSW":'${nstep[0]}'
}' -kpt 'Kpoints.gamma_automatic((1,1,1))' \
--ensemble nvt -y incar_ldau.yaml -o melt_nvt -v vasp_gam #-r false
#exit

# 2. Quench(NVT, PBEU)
python3 $vaspmpset melt_nvt/CONTCAR md None $nproc -incar '{
  "ENCUT":'$ecut_md',
  "ALGO":"Normal",
  "POTIM":'$dt',
  "TEBEG":5000,
  "TEEND":300,
  "NSW":'${nstep[1]}'
}' -kpt 'Kpoints.gamma_automatic((1,1,1))' \
--ensemble nvt -y incar_ldau.yaml -o quench_nvt -v vasp_gam

fi  # do_md

if [ $do_relax -eq 1 ]; then
echo "do Relax"

# 3. Relax(PBEU)
python3 $vaspmpset quench_nvt/CONTCAR relax None $nproc -incar '{
  "ENCUT":'$ecut',
  "ALGO":"Normal",
  "NSW":10000
}' -kpt 'Kpoints.gamma_automatic((2,2,2))' \
-y incar_ldau.yaml -o relax -v vasp_std

# 4. SCF(PBEU)
python3 $vaspmpset relax/CONTCAR scf None $nproc -incar '{
  "ENCUT":'$ecut',
  "ALGO":"Normal"
}' -kpt 'Kpoints.gamma_automatic((2,2,2))' \
-y incar_ldau.yaml -o scf -v vasp_std

# 5. NSCF(PBEU)
python3 $vaspmpset relax/CONTCAR nscf scf $nproc -incar '{
  "ENCUT":'$ecut',
  "ALGO":"Normal"
}' -kpt 'Kpoints.gamma_automatic((4,4,4))' \
-y incar_ldau.yaml --project_lm true -o nscf -v vasp_std

fi  # do_relax

# 6. Vo
if [ $do_Vo -eq 1 ]; then
echo "do Vo"

echo "./calc_Vo_para.sh Vo relax/CONTCAR 8 -1 1000" \
| qsub -d `pwd` -q q1 -N Vo${cIn}${cGa}${cZn} -l select=1:ncpus=8 -o Vo.log

