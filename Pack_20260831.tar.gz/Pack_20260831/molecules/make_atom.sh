#!/bin/bash

elem=$1
lxyz=15.0  # ang.

poscar_file="POSCAR_$elem"
echo "poscar_file = $poscar_file"

lx=$(echo "$lxyz - 0.5" | bc -l); ly=$lxyz; lz=$(echo "$lxyz + 0.5" | bc -l)
python3 -c "from pymatgen.core import Molecule;\
 mol=Molecule(['$elem'],[(0,0,0)]);\
 st=mol.get_boxed_structure($lx,$ly,$lz);\
 st.to('$poscar_file', fmt='poscar')"

