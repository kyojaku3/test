#!/usr/bin/env python3
# usage: $ python3 calc_bonds.py rdf.csv -s Al Sb -f test_md2/PROJECT/md/CONTCAR -p1 -p2

import argparse
import itertools
import os
import sys
import yaml
import pandas as pd
import matplotlib.pyplot as plt
from pymatgen.core import Structure
from pymatgen.io.vasp import Vasprun
from analysis.diffusion.aimd.rdf import RadialDistributionFunctionFast
from pymatgen.analysis.local_env import CrystalNN, CutOffDictNN

parser = argparse.ArgumentParser()
parser.add_argument('rdffile', type=str)
parser.add_argument('-s', '--species', type=str, nargs='*')
parser.add_argument('-p1', '--is_plot_rdf', action='store_true')
parser.add_argument('-p2', '--is_plot_bond', action='store_true')
parser.add_argument('-v', '--visfile', type=str)
parser.add_argument('-fs', '--structfile', type=str)
parser.add_argument('-fc', '--cutoff_file', type=str)

args = parser.parse_args()

df = pd.read_csv(args.rdffile, sep=' ')
pair_list = list(itertools.combinations_with_replacement(args.species, 2))
col = df.columns

if args.is_plot_rdf:
    plt.rcParams["font.size"] = 14
    fig = plt.figure()
    ax=fig.add_subplot(1,1,1)

    for (s1,s2) in pair_list:
        pair_name = "{s1}-{s2}".format(s1=s1,s2=s2)
        r_name = "r_{}".format(pair_name)
        ax.plot(df[r_name], df[pair_name], label=pair_name)
 
    ax.grid()
    ax.set_xlabel('Distance [nm]')
    ax.set_ylabel('RDF') 
    plt.legend(loc='best')
    plt.show()


cut_off_dict = {}
coordnum = {}
for (s1,s2) in pair_list:
    pair_name = "{s1}-{s2}".format(s1=s1,s2=s2)
    r_name = "r_{}".format(pair_name)

    r = df[r_name].to_list()
    rdf = df[pair_name].to_list()

    rdf_max = max(rdf)
    r_max = r[rdf.index(rdf_max)]
    print("pair = {p}, r_max = {r}".format(p=pair_name, r=r_max))

    cut_off_dict[('{}'.format(s1),'{}'.format(s2))] = r_max
    coordnum[pair_name] = 0

print(cut_off_dict)    

if args.cutoff_file:
    cut_off_dict = {}
    with open(args.cutoff_file, 'r') as file:
        cutoff_data = yaml.safe_load(file)
    for key,val in cutoff_data.items():
        cut_off_dict[('{}'.format(val[0]),'{}'.format(val[1]))] = val[2]
    print(cut_off_dict)
#sys.exit()

if args.structfile:
    structure = Structure.from_file(args.structfile)

elif args.visfile:
    v = Vasprun(args.visfile)    
    structure = v.ionic_steps[-1]["structure"]

nn = CutOffDictNN(cut_off_dict)

natom = structure.num_sites
nn_info_list = [ nn.get_nn_info(structure, iatom) for iatom in range(natom) ]
#print(nn_info_list[8])
#print(type(nn_info_list[8]))
#print(nn_info_list[8][0])
#print(type(nn_info_list[8][0]))
#print(nn_info_list[8][0]['site'])
#print(type(nn_info_list[8][0]['site']))
#print(nn_info_list[8][0]['site']._species)
#print(type(nn_info_list[8][0]['site']._species))
#print(nn_info_list[8][0]['site']._species.reduced_formula)


for species, nn_info in zip(structure.species, nn_info_list):
    s1 = species.symbol    
    for nei in nn_info:
        s2 = nei['site']._species.reduced_formula
        pair_name = "{s1}-{s2}".format(s1=s1,s2=s2)
        if pair_name in coordnum.keys():
            coordnum[pair_name] += 1

# delete double count
for (s1,s2) in pair_list:
    pair_name = "{s1}-{s2}".format(s1=s1,s2=s2)
    if s1 == s2:
        coordnum[pair_name] = 0.5 * coordnum[pair_name]

print(coordnum)


if args.is_plot_bond:
    plt.rcParams["font.size"] = 14
    fig = plt.figure()
    ax=fig.add_subplot(1,1,1)

    ax.pie(coordnum.values(), labels=coordnum.keys(), autopct="%1.0f%%")
    plt.show()

