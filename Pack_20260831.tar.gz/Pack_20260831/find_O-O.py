#!/usr/bin/python3
# usage: 
# $ python3 find_O-O.py work_md/PROJECT/md_2/vasprun.xml 2.0 -s 10 -e 20 
# $ gnuplot -persist -e "plot 'n_OO.dat' ev ::1 u 1:2 w lp"
# $ time python3 find_O-O.py work_md/PROJECT/md_2/vasprun.xml 2.0 -e 100 -o n_OO.csv
# $ python3 -c "import pandas,matplotlib; df=pandas.read_csv('n_OO.csv'); df.plot('step'); matplotlib.pyplot.show()"

import argparse
import sys
import os
import pandas as pd
from pymatgen.core import Structure
from pymatgen.io.vasp import Vasprun

# Do not display some warnings
import warnings
warnings.filterwarnings("ignore",message="Overriding the POTCAR functional is generally not recommended ") # @ class DictSet in pymatgen/io/vasp/sets.py
warnings.filterwarnings("ignore",message="POTCAR with symbol") # @ class PotcarSingle in pymatgen/io/vasp/input.py

parser = argparse.ArgumentParser()
parser.add_argument('pos_file', type=str, help='POSCAR or vasprun.xml')
parser.add_argument('rcut', type=float)
parser.add_argument('-o', '--out_file', type=str, default='n_OO.dat')
parser.add_argument('-s', '--start', type=int)
parser.add_argument('-e', '--end', type=int)

args = parser.parse_args()
print("Reading file = ", args.pos_file)
print("rcut = ", args.rcut)
print("out_file = ", args.out_file)

if os.path.basename(args.pos_file) == 'vasprun.xml':
  steps=Vasprun(args.pos_file).ionic_steps
  nstep=len(steps)
  start = args.start if args.start else 0
  end = args.end if args.end else nstep
  print("start={s} end={e}".format(s=start, e=end))
#  sys.exit()
  st_list = [steps[istep]['structure'] for istep in range(nstep)]
  st_list = st_list[start : end + 1]
  out_steps = list(range(start,end + 1))
else:
  st_list = [Structure.from_file(args.pos_file)]
  out_steps = [0]

n_OOs=[]
for istep, st in zip(out_steps, st_list):
  OO_tmp=[ [(i, site.index)
    for site in st.get_neighbors(st.sites[i],args.rcut) if site.specie.symbol=='O']
    for i in range(st.num_sites) if st.species[i].symbol=='O' ]
  OO=[l for l in OO_tmp if len(l)>0]
  print(OO)
  n_OO=sum( [len(l) for l in OO] )/2
  print("{}: # of O-O = {}".format(istep, n_OO))
  n_OOs.append(n_OO)


df = pd.DataFrame(zip(out_steps, n_OOs), columns=['step','n_OO'])

path, ext = os.path.splitext( os.path.basename(args.out_file) )
if ext == '.csv':
  df.to_csv(args.out_file, index=False)
else:
  df.to_csv(args.out_file, index=False, sep=' ')

