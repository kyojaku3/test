#!/bin/bash

bulk_dir=$1
defect_dir=$2
mol_dir=$3
elem=$4  # O
nmol=$5

# Atomization energies of homonuclear diatomic molecule in PRL1996Perdew
declare -A atomization_energies=( ["H"]=109 ["Li"]=24 ["N"]=229 ["O"]=121 ["F"]=39 ["P"]=117 ["Cl"]=58 )

function get_energy(){
  outdir=$1
  if [ ! -f "${outdir}/vasprun.xml" ]; then
    echo "error"
    return 1
  fi

  etotal=$( ./ve.sh  ${outdir}/vasprun.xml | awk '{print $1}')
  echo $etotal
}

e_bulk=$(get_energy $bulk_dir)
echo $e_bulk

e_elem_dft=$(get_energy $mol_dir)
echo $e_elem_dft
KCalbyMol_eV=0.0433641008036641  # $ gnuplot -e "load 'param.gp'; print KCalbyMol_eV"
if [[ ${atomization_energies[$elem]:+exists} ]]; then
  e_elem_exp=${atomization_energies[$elem]}
  echo "$elem exist in atomization_energies with values: $e_elem_exp"
  e_elem=$(echo "2 * $e_elem_dft - $e_elem_exp * $KCalbyMol_eV" | bc)
  e_elem=$(echo "scale=16; $e_elem / 2" | bc)
  echo "Corrected energy = ${e_elem} [eV/atom]"
else
  echo "$elem does not exist in atomization_energies."
  e_elem_exp="None"
  e_elem=$e_elem_dft
fi
#exit

out_path="${defect_dir}/eform.dat"
echo "output file = $out_path"

echo "# e_bulk=$e_bulk, bulk_dir=$bulk_dir" > $out_path
echo "# e_elem_dft=$e_elem_dft, mol_dir=$mol_dir" >> $out_path
echo "# e_elem_exp(kCal/mol)=$e_elem_exp, e_elem=$e_elem" >> $out_path
echo "idx  e_defect  e_form" >> $out_path


for((idx=1;idx<=$nmol;idx++)); do
  echo -n "$idx "
  outdir="$defect_dir/$idx/relax"
  e_defect=$(get_energy $outdir)
  e_int=$(echo "$e_defect + $e_elem - $e_bulk" | bc -l)
  echo "$idx $e_defect $e_int" >> $out_path
done
echo "finished"

