#!/usr/bin/python3
# $ python3 calc_rdf.py test_md2/PROJECT/md -s Al Sb
# $ gnuplot -persist -e "optcsv=1; load 'csv.gp'; plot 'rdf.csv' u 1:2 w lp, 'rdf.csv' u 3:4 w lp, 'rdf.csv' u 5:6 w lp"

import argparse
import itertools
import os
import sys
import pandas as pd
from pymatgen.core import Structure
from pymatgen.io.vasp import Vasprun
from analysis.diffusion.aimd.rdf import RadialDistributionFunctionFast

parser = argparse.ArgumentParser()
parser.add_argument('-v', '--visfile', type=str)
parser.add_argument('-f', '--poscarfile', type=str)
parser.add_argument('-s', '--species', type=str, nargs='*')
parser.add_argument('-o', '--outfile', type=str, default='rdf.txt')
args = parser.parse_args()

if args.poscarfile:
    print("Read POSCAR file")
    structure = Structure.from_file(args.poscarfile)
    s_list=[structure]

elif args.visfile:
    print("Read vasprun.xml")
    v = Vasprun(args.visfile)    
    s_list=[s["structure"] for s in v.ionic_steps]

obj=RadialDistributionFunctionFast(structures=s_list)

pair_list = list(itertools.combinations_with_replacement(args.species, 2))
print(pair_list)

df = pd.DataFrame()
for (s1,s2) in pair_list:
    pair_name = "{s1}-{s2}".format(s1=s1,s2=s2)
    r_name = "r_{}".format(pair_name)
    print(pair_name) 

    r, rdf = obj.get_rdf(s1, s2)
    df[r_name] = list(r)
    df[pair_name] = list(rdf)

df.to_csv(args.outfile, index=False, sep=' ')
sys.exit()

